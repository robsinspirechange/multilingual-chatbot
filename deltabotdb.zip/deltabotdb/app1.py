from flask import Flask, redirect, url_for
import pandas as pd
app = Flask(__name__)
df = pd.read_csv('1.csv')

@app.route('/<project>/<param>')
def hello_admin(project,param):
	print(project)
	temp = df[df.projects.str.contains(str(project))][str(param)].values[0]
	return str(temp)

if __name__ == '__main__':
	app.run(debug = True)